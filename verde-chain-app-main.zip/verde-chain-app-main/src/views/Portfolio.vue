<template>
<div class="portfolio">
<div class="container">
<h1>Your Portfolio</h1>
<!-- Portfolio content -->
</div>
</div>
</template>
