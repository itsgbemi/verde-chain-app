<template>
<div class="rewards">
<div class="container">
<h1>Your Rewards</h1>
<!-- Rewards content -->
</div>
</div>
</template>
